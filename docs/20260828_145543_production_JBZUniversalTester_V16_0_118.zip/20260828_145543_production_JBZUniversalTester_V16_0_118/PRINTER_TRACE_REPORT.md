# Printer COM Trace Report V8.9

- Serial opens: **1**
- TX requests: **5**
- TX payload bytes captured: **2540**
- Complete EPL jobs ending P1: **5**
- Incomplete streams without final P1: **0**
- Failed WriteFile results: **0**
- Truncated payloads: **0**
- Payloads with mixed CRLF/bare-LF: **5**
- RX responses with data: **0**

## Đánh giá nhanh

- Có payload trộn CRLF với LF; so sánh byte gốc Htdrv trước khi sửa template.

## File đối chiếu

- `printer_serial.csv`: mở cổng, cấu hình COM, TX/RX và kết quả WriteFile.
- `printer_payloads/job_*.bin`: byte chính xác của từng lệnh in hoàn chỉnh.
- `printer_payloads/incomplete_*.bin`: dữ liệu khiến máy in có thể còn chờ lệnh.
