# JBZ TRACE V8.8 — Tóm tắt session

- Profile: **production**
- Tổng event: **101991**
- Logger errors: **0**
- Event bị bỏ do queue đầy: **0**
- Frame I/O có thay đổi: **126**
- Pin activity: **5**
- Raw D2XX events: **101639**
- I/O transition candidates: **10**
- Printer COM events: **47**
- Printer TX requests: **5**
- Printer TX bytes captured: **2540**
- Complete printer jobs ending P1: **5**
- Incomplete printer streams: **0**
- Kết quả UI: **NG, NG**
- Registration-related event: **0**
- Startup Discovery event: **0**

## Output

- `timeline.csv` — toàn bộ timeline đã lọc
- `events.jsonl` — event gốc
- `workflow_light.csv` — workflow Production nếu có
- `jbz_io_changes.csv` — frame decoder 80/A0/C0 (giả thuyết, emit mọi frame trong deep scan)
- `d2xx_raw_io.csv` — raw FT_Read/FT_Write/FT_GetQueueStatus, kể cả empty poll
- `scan_cadence.csv` — delta giữa Read/Queue/Frame để đo cadence thật
- `io_transition_candidates.csv` — added/removed IO giữa các frame để suy mapping
- `startup_discovery.csv` — broad metadata file/registry/path-check trong ~2 giây đầu, không payload
- `static_target_analysis.json` / `STATIC_TARGET_ANALYSIS.md` — PE/import/string/signature static map
- `static_runtime_correlation.csv` / `STATIC_RUNTIME_CORRELATION.md` — static ↔ runtime hardware/call-path correlation
- `registration_timeline.csv` — timeline Registration
- `registration_callsites.csv` — callsite/backtrace liên quan
- `registration_dataflow.csv` — luồng Volume Serial / ID / input / validation
- `registration_flow.json` — tóm tắt machine-readable
- `REGISTRATION_DATAFLOW.md` — báo cáo data-flow
- `ida_targets.txt` — danh sách offset candidate để tra cứu tĩnh
- `REGISTRATION_SUMMARY.md` — tóm tắt Registration
- `MACHINE_REGISTRATION_REPORT.md` — báo cáo nhanh máy/ID/profile/status
- `profile_registration_storage.csv` — Tester Lock / Option Lock và nơi lưu
- `hardware_snapshot.json` — snapshot máy trước khi chạy EXE ở profile Registration

Production profile giữ V8.6 Deep Scan; Registration profile dùng V8.8 verified correlation. Không dùng Deep Scan để chạy production dài giờ vì overhead cao hơn.
