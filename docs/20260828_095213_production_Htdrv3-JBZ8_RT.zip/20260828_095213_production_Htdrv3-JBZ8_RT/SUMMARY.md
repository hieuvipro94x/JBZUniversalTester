# JBZ TRACE V8.1 DUAL — Tóm tắt session

- Profile: **production**
- Tổng event: **227**
- Logger errors: **0**
- Event bị bỏ do queue đầy: **0**
- Frame I/O có thay đổi: **45**
- Pin activity: **3**
- Kết quả UI: **FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL, FAIL**
- Registration-related event: **0**

## Output

- `timeline.csv` — toàn bộ timeline đã lọc
- `events.jsonl` — event gốc
- `workflow_light.csv` — workflow Production nếu có
- `jbz_io_changes.csv` — I/O Production nếu có
- `registration_timeline.csv` — chỉ có ý nghĩa ở profile Registration
- `REGISTRATION_SUMMARY.md` — chỉ có ý nghĩa ở profile Registration
- `hardware_snapshot.json` — snapshot máy trước khi chạy EXE ở profile Registration

V8.1 giữ FT_GetQueueStatus/GDI/network broad hooks ở trạng thái tắt để tránh làm chậm phần mềm gốc.
